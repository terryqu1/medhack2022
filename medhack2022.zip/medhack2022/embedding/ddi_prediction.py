import pickle
import pandas as pd
from rdkit.Chem import AllChem as Chem
from rdkit.Chem.Draw import IPythonConsole
from rdkit.Chem import PandasTools
from rdkit.Chem import Draw
from rdkit import DataStructs
import rdkit
import numpy as np

def ddi_predict(drug1, drug2):
    filename = 'finalized_model.sav'
    model = pickle.load(open(filename, 'rb'))

    filename = 'drug_dict.sav'
    drug_dict = pickle.load(open(filename, 'rb'))

    if (drug1 not in drug_dict.keys()) | (drug2 not in drug_dict.keys()):
        return 0

    input1_smiles = drug_dict[drug1]
    input2_smiles = drug_dict[drug2]

    ddi_dict = {'name': [drug1, drug2], 'smiles': [input1_smiles, input2_smiles]}

    ddi_df = pd.DataFrame.from_dict(ddi_dict)

    PandasTools.AddMoleculeColumnToFrame(ddi_df,'smiles','struc',includeFingerprints=True)

    fplist = []
    for mol in ddi_df['struc']:
        fp = Chem.GetMorganFingerprintAsBitVect( mol,2 )
        fp_arr = np.zeros((0,), dtype=int)
        DataStructs.ConvertToNumpyArray(fp, fp_arr)
        fplist.append(fp_arr)
    ddi_df['drug_a_fp']=fplist
    
    # rules for combining two fingerprints into 1
    input1_fp_arr = ddi_df.at[0, 'drug_a_fp']
    input2_fp_arr = ddi_df.at[1, 'drug_a_fp']

    combined_fp_arr = np.empty(2048, dtype=int)

    for j in range(2048):
        if (input1_fp_arr[j] == 0 & input2_fp_arr[j] == 0) | (input1_fp_arr[j] == 1 & input2_fp_arr[j] == 1):
            combined_fp_arr[j] = 1
        else:
            combined_fp_arr[j] = 0
    
    return (int(model.predict(combined_fp_arr.reshape(1,-1))) + 1)